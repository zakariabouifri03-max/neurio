SampleIsland - a NovaForge Engine game
==========================================

How to play
-----------
  Double click SampleIsland.exe (Windows 10 or newer, 64 bit).
  No installer and no editor are needed: the executable loads
  game.json and the Assets folder that sit next to it.

Controls
--------
  W A S D ........ move        Shift ......... run
  Space .......... jump        Mouse ......... look around
  Left click ..... attack      E ............. interact
  Esc or P ....... pause       F1 ............ performance stats
  F2 ............. screenshot  R ............. respawn after dying

Command line
------------
  SampleIsland.exe --help                 usage
  SampleIsland.exe --width 1920 --height 1080
  SampleIsland.exe --headless --seconds 5 --screenshot shot.png
      (runs without a window - useful to check the game on a machine
       with no display, and it writes Logs/runtime.log the same way)

Files
-----
  SampleIsland.exe        the game (NovaForge runtime + this project)
  game.json          start scene, window size, quality
  Assets/            scenes, materials and Lua scripts
  Project/           the editable project (open it in the editor)
  Logs/              runtime.log, written when the game runs
  BUILD_INFO.txt     exactly what was exported and when

Rendering in this build: NovaForge CPU software rasterizer
(no GPU required; see docs/RENDERING.md in the source tree).
