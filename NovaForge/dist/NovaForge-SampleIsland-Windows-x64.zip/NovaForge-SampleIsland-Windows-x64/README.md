# NovaForge Engine - standalone game (Windows x64)

`NovaForgeGame.exe` is the NovaForge **runtime**: a separate executable, not a renamed copy of the
editor. It contains no editor code - it reads `project.json`, `Settings/` and `Assets/` from its own
folder and plays whatever project it finds there.

    NovaForgeGame.exe        the game - statically linked, no installer, no dependencies
    project.json             game settings (window, physics, input map, start scene)
    Assets/Scenes/*.nfscene  the level - human readable JSON scene format
    Assets/Scripts/*.nfscript behaviour scripts used by the level
    Assets/Audio/*.wav       sound clips

## Run it

1. Unpack this folder anywhere (the Desktop is fine).
2. Double-click `NovaForgeGame.exe`.

Requires Windows 10/11 x64 and an OpenGL 3.3 capable GPU driver (any 2012+ GPU). Nothing else is
needed: the UCRT ships with Windows and no Visual C++ redistributable is used.

Command line:

    NovaForgeGame.exe                            play
    NovaForgeGame.exe --console                  keep the log window open (Logs/Game.log is always written)
    NovaForgeGame.exe --fullscreen               start fullscreen
    NovaForgeGame.exe --width 1920 --height 1080
    NovaForgeGame.exe --headless --frames 300    run the simulation without a window (smoke test)
    NovaForgeGame.exe --screenshot frame.png     render one frame to a PNG and exit
    NovaForgeGame.exe --project <folder>         play a different project folder

## Controls

| Input | Action |
|---|---|
| W A S D / arrow keys | Move |
| Mouse | Look - click the window to capture the cursor |
| Space | Jump |
| Shift | Sprint |
| E / Enter | Interact (gate, pickups) |
| Left mouse / F | Attack - the NPCs fight back |
| R | Respawn after dying |
| Esc | Pause menu / release the cursor |
| F5 | Quick save the current scene state |
| F11 | Toggle fullscreen |
| F1 | Toggle the on-screen HUD |

## What is in this sample

* 60 x 60 island with a raised platform, pillars, crates and a script driven spinning crate
* third person player: capsule collider, gravity, jump, sprint, 120 HP, block/respawn
* three NPCs driven by the AI state machine: `Guard` and `Patrol` walk their route,
  `Brute` and `Scout` chase and attack on sight
* a gate that opens when you walk into its trigger volume (own script + interaction prompt)
* health and ammo pickups, a welcome trigger, and a quest ("Survive the island")
* a directional sun with shadows plus a point lamp, ambient audio loop
* gameplay log in `Logs/Game.log`

## Where this came from

This folder is exactly what the editor's **Build Game** button produces: the build system stages
the game executable, `project.json`, `Assets/`, `Settings/`, the engine sources under `Engine/`
plus `Build.bat` / `build.sh` so the game can be rebuilt from source without the editor.
