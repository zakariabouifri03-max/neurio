# NovaForge Engine - editor (Windows x64)

`NovaForge.exe` is the editor: the tool where scenes are built, played and exported.
This folder also contains the **Sample Island** project, so you can open it and press Play
immediately - and it is the same content the standalone game package ships.

## Run it

Double-click `NovaForge.exe`, then `File > Open Project` and choose this folder (it contains
`project.json` + `Assets/`), or `File > New Project` to start from scratch.

## Quick tour

* **Toolbar** - Play / Pause / Step / Stop, Build Game, Save / Save As, Undo / Redo, gizmo mode
* **Scene Hierarchy** (left) - create, rename, duplicate, parent, delete; right-click for
  *Add Ground / Light / Player / NPC / Door / Pickup / Trigger Volume / Audio Source / Quest*
* **Viewport** (centre) - RMB orbit, MMB pan, wheel zoom, WASD free-fly, W/E/R for
  Move/Rotate/Scale gizmos, Ctrl snaps, click selects, Ctrl+click multi-selects
* **Inspector** (right) - every component exposes editable fields, assets and confirmation
  dialogs for destructive operations
* **Asset Browser** - Import GLB / GLTF / OBJ / FBX / PNG / JPG / WAV, drag a model into the scene
* **AI Assistant** (right dock) - describe a change in plain language; it edits the *real* project
  files and components, shows a preview of every AI ACTION -> file/component touched, requires
  Apply, and can Revert the whole change set
* **Console / Logs** - errors and warnings are reported there and written to `Logs/Editor.log`
* **Play mode** - the game runs inside the viewport with the same systems as the exported build
  (physics, AI, scripting, audio, collisions, HUD)

## End to end acceptance flow

Create Project -> Import GLB -> drag the model into the scene -> Add Ground -> Add Light ->
Create Player -> Add Collider -> Add NPC -> Play -> walk around -> interact / fight ->
Save project -> Build Game -> close the editor -> launch the produced `<Project>.exe`.

The build output (default `Builds/<Project>/`) is a standalone folder exactly like the Sample
Island package: a separate runtime executable, `project.json`, `Assets/`, `Engine/` sources and
`Build.bat` / `build.sh` (verified rebuild scripts - `build.sh` cross-compiles the same .exe from
the packaged sources).

Documentation: `docs/` in the repository (architecture, formats, build system, AI assistant,
test suite) and `BuildReport.txt` inside every build output.
